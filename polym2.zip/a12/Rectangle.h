#ifndef _RECTANGLE_H
#define _RECTANGLE_H
#include "Area.h"
using namespace std;
class Rectangle : public virtual Area {
	public:
		Rectangle(string n, double a, double b);
		~Rectangle();
		double calcArea() const;
		double calcPerimeter() const;
	protected:
		double length;
		double width;
};

#endif
