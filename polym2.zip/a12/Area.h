/*
CH-230-A
a12 p7.cpp
Xhesilda Lutaj
x.lutaj@jacobs-university.de
*/
#ifndef _AREA_H
#define _AREA_H

class Area {
	public:
		Area(std::string n);
		virtual ~Area();
		std::string getColor();
		virtual double calcArea() const = 0;
		virtual double calcPerimeter() const = 0;
	private:
		std::string color;
};
#endif
