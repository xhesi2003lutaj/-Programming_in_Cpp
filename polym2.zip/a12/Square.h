#ifndef _SQUARE_H
#define _SQUARE_H
#include <iostream>
#include "Rectangle.h"
using namespace std;
class Square : public Rectangle {
    public:
		Square(string n, double s);
		~Square();
		double calcArea() const;
		double calcPerimeter() const;
	protected:
		double side;
};

#endif // _SQUARE_H