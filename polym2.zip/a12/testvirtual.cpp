
#include <iostream>
using namespace std;
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"


int main()
{
    int random, obj_id;
    string names[4]= {"RED","BLACK","BLUE","VIOLET"};
    //random number generator
    srand(static_cast<unsigned int>(time(0)));
    //Main loop
    for(int count = 0; count < 25; count++)
    {
        random = (rand() % 4);
        obj_id = (rand() % 4);
        
        if(obj_id==3) 
        {
            //getting the nwo random numbers
            int obj1=(rand() % 95)+5;
            int obj2=(rand() % 95)+5;
			Rectangle a(names[random], (double)obj1, (double)obj2);
            cout<<"Rectangle "<<names[random]<<" calcPerimeter: "
                <<a.calcPerimeter()<<" calcArea: "<<a.calcArea()<<endl;

        }else if(obj_id==2) 
        {
            int obj1=(rand() % 95)+5;
            Square a(names[random], (double)obj1);
            cout<<"Square "<<names[random]<<" calcPerimeter: "
                <<a.calcPerimeter()<<" calcArea: "<<a.calcArea()<<endl;
        }
        else if(obj_id==1) 

        {
            int obj1=(rand() % 95)+5;
            Circle a(names[random], (double)obj1);
            cout<<"Circ "<<names[random]<<" calcPerimeter: "
                <<a.calcPerimeter()<<" calcArea: "<<a.calcArea()<<endl;
        }
        else if(obj_id==0)
        {
            int obj1=(rand() % 95)+5;
            int obj2=(rand() % 95)+5;
            if(obj1<obj2)//it wouldn't make sense as the area woul be negative
                swap(obj1, obj2);
            Ring a(names[random], (double)obj1, (double)obj2 );
            cout<<"Ring "<<names[random]<<" calcPerimeter: "
                <<a.calcPerimeter()<<" calcArea: "<<a.calcArea()<<endl;
        }
    }
    return 0;
}






// int main() {

// string names[4]{"RED", "BLACK", "VIOLET", "BLUE"};

// srand(static_cast<unsigned int>(time(0)));
// int random ,id;

//  for(int i=0;i<25;i++){
//    random=(rand()%4);
//    id=(rand()%4);
   
//     if(id==0){
// 		cout<<"Creating circle:";
// 		int obj1;
// 		obj1=(rand()%95)+5;
// 		Circle a(names[random],obj1);
// 		cout<<"CIrcle"<<names[random]<<"Perimertre: "<<a.calccalcPerimeter()<<"calcArea: "<<a.calccalcArea()<<endl;

// 	}










//  }

// 	return 0;
// }
