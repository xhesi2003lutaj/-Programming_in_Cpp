#ifndef _RING_H
#define _RING_H
#include "Circle.h"
using namespace std;
class Ring : public  Circle {
	public:
		Ring(string n, double outer, double inner);
		~Ring();
		double calcArea() const;
		double calcPerimeter() const;
	private:
		double innerradius;
};

#endif